/* Ejercicio4 de la relación*/


#include <iostream>
using namespace std;
int main () {
	int dato;
	cout << "Introduzca un valor entero distinto de cero: "<< endl;
	cin>> dato;
}


/* El programa se ejecutará pero una vez dado
el valor que nos pide el programa finalizará*/