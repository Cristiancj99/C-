/* programa que te repite 1000 veces 
una frase.*/



#include <iostream>
using namespace std;
int main () { 

	int numero = 0.0;

	do {  // bucle para repetir 1000 veces la frase
	cout << " pienso, luego programo" << endl;
	numero = numero +1 ;
	} while ( numero <= 1000 );
}