#include <iostream>

using namespace std;

int main () {



	for ( int progresion=0.0; progresion <= 10; progresion= progresion + 1 ) {

		

		cout << " 7 x " << progresion << " = " <<  7* progresion << endl;

	}

}