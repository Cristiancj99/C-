#include <iostream>
#include <string>
using namespace std;

int main () {

	string cadenanumeros;

	cout<< "BIENVENIDO AL FABULOSO PROGRAMA DE LOS SAN FERMINES" << endl;
	
	cout << "Comience a introducir el numero de toros y seguidamente la velocidad de cada uno: "<< endl;

	getline (cin, cadenanumeros);

	cout << cadenanumeros;
}

//programa incompleto. Con el string teniamos que hacer un montón de cosas que no sabia hacer, tenía pensado otr forma pero no me dio tiempo.