#include <iostream>
using namespace std;
int main () {

	int numero = 0; // variable para dar valor ( x 1,2,3... )

	while ( numero <= 10 ) {
		cout << " 7 x " << numero << " = " << 7 * numero << endl;
		numero= numero + 1;	
	
	}
}