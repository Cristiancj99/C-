#include <iostream>
using namespace std;
int main (){

	for ( int progresion=1;progresion <=10;progresion = progresion + 1) { // ptogrsion para que lo haga 10 veces.
		
		cout << "pienso, luego programo" << endl;
	}
}