#include <iostream>
using namespace std;
int main () {

	int numero= 1 ; // variable que utilzaremos para contar hasta el número que sea.

	while (numero <= 10 ) {
		
		cout << " pienso, luego programo. "<< endl;
		numero = numero + 1;
	}
}
